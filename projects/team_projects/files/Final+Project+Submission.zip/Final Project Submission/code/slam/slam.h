#ifndef SLAM_H_
#define SLAM_H_

#include <vector>
#include "Aria.h"
#include "util/geom.h"
#include "navigation/labeledmap.h"
#include "ros/ros.h"//Should not be here

//Note: should really have been a Singleton class to enable testing better 
//Globals are no good
void init_slam(ArRobot*);
void lock_slam_map();
void unlock_slam_map();
LabeledMap get_slam_map();

#endif /* SLAM_H_ */
