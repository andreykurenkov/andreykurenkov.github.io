#ifndef LABELED_MAP_H_
#define LABELED_MAP_H_

using namespace std;

typedef struct _plant {
	double x, y, z;
	double width, length, height;
	int id;
} plant;

typedef struct _labeled_map {
	vector<plant> plants;	
	se3 robot_pose;
} labeled_map;
typedef labeled_map* LabeledMap;


#endif
