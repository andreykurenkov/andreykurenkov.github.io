#include "slam/slam.h"
#include "geometry_msgs/PoseArray.h"
#include "sensor_msgs/PointCloud2.h"
#include "tf/transform_broadcaster.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <tf/LinearMath/Matrix3x3.h>
#include <tf/LinearMath/Quaternion.h>

#ifdef COMPILING_WITH_PCL
	#include <pcl/conversions.h> 
	#include <pcl/point_cloud.h>
	#include <pcl/point_types.h>
	#include <pcl/io/pcd_io.h>

	#include <pcl/PCLPointCloud2.h>
	#include <pcl_conversions/pcl_conversions.h>

	#include <pcl/filters/statistical_outlier_removal.h>
	#include <pcl/filters/extract_indices.h>
	#include <pcl/filters/radius_outlier_removal.h>
	#include <pcl/filters/conditional_removal.h>
	#include <pcl/filters/voxel_grid.h>

	#include <pcl/kdtree/kdtree.h>
	#include <pcl/segmentation/extract_clusters.h>
#endif

//cm
#define MIN_HEIGHT 10 
#define DIST_THRESHOLD 1.0
#define MM_IN_M 1000.0

ArRobot* robot;
ros::NodeHandle* rosHandle;
tf::TransformBroadcaster* tfBroadcaster;
ros::Publisher kinect_cleaned_publisher;

LabeledMap slam_map;
pthread_mutex_t slam_map_mutex;

void cloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg);
void trajectoryCallback(const geometry_msgs::PoseArray::ConstPtr& msg);

#ifdef COMPILING_WITH_PCL
	void cleanPointCloud(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr out);
	void removeLowPoints(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr out);
	void trajectoryCallback(const geometry_msgs::PoseArray::ConstPtr& msg);
#endif

void lock_slam_map() {
        pthread_mutex_lock(&slam_map_mutex);
}

void unlock_slam_map() {
        pthread_mutex_unlock(&slam_map_mutex);
}

void odometry_update(){
    while(true){	
		robot->lock();
		double ex = robot->getEncoderX() / MM_IN_M;
		double ey = robot->getEncoderY() / MM_IN_M;
		double et = to_radians(robot->getEncoderTh());
		robot->unlock();
		tf::Transform transform;
		transform.setOrigin( tf::Vector3(ex, ey, 0.0) );
		tf::Quaternion q;
		q.setRPY(0, 0, et);
		transform.setRotation(q);
		tfBroadcaster->sendTransform(tf::StampedTransform(transform, ros::Time::now(), "odom", "agribot"));
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

void start_odometry_loop(){
	std::thread(odometry_update).detach();
}

void init_slam(ArRobot* arrobot) { 
        if (pthread_mutex_init(&slam_map_mutex, NULL) != 0)
        {
            printf("\n slam mutex init failed\n");
            exit(1);
        }
        robot = arrobot;
        rosHandle = new ros::NodeHandle("slam");
        rosHandle->subscribe("kinect2/depth_highres/points", 10, cloudCallback);
        rosHandle->subscribe("/omnimapper_ros_node/trajectory", 10, trajectoryCallback);
        kinect_cleaned_publisher = rosHandle->advertise<sensor_msgs::PointCloud2>("kinect_filtered_cloud", 10);
        slam_map = new labeled_map();
        tfBroadcaster = new tf::TransformBroadcaster();
        start_odometry_loop();      
}

LabeledMap get_slam_map() {
	return slam_map;
}

void trajectoryCallback(const geometry_msgs::PoseArray::ConstPtr& msg) {
	geometry_msgs::Pose currPose = msg->poses.back();
	geometry_msgs::Quaternion quat = currPose.orientation;

	vec3 trans = (vec3){{currPose.position.x,currPose.position.y,currPose.position.z}};

 	tf::Quaternion btQuat(quat.x,quat.y,quat.z,quat.w);
	tf::Matrix3x3 rotMatrix(btQuat);
	so3 rot;
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			rot.data[i][j] = rotMatrix[i][j];
		}
	}
	lock_slam_map();
		slam_map->robot_pose.translation = trans;
		slam_map->robot_pose.rotation = rot;
	unlock_slam_map();
}

#ifdef COMPILING_WITH_PCL
	void cleanPointCloud(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr out){
		  pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
		  sor.setInputCloud (cloud);
		  sor.setMeanK (50);
		  sor.setStddevMulThresh (1.0);
		  sor.filter (*out);
	}


	void removeLowPoints(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr out){
	  // build the condition
	  pcl::ConditionAnd<pcl::PointXYZ>::Ptr range_cond (new
		  pcl::ConditionAnd<pcl::PointXYZ> ());
		range_cond->addComparison (pcl::FieldComparison<pcl::PointXYZ>::ConstPtr (new
		  pcl::FieldComparison<pcl::PointXYZ> ("z", pcl::ComparisonOps::GT, MIN_HEIGHT)));

	  // build the filter
	  pcl::ConditionalRemoval<pcl::PointXYZ> condrem(range_cond);
	  condrem.setInputCloud (cloud);
	  condrem.setKeepOrganized(true);

	  // apply filter
	  condrem.filter (*out);
	}

	void cloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg) {
	  //Convert ROS to PCL
	  pcl::PointCloud<pcl::PointXYZ> cloud;
	  pcl::fromROSMsg(*msg, cloud);

	  //Filter with PCL
	  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_to_clean (&cloud);
	  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_cleaned (new pcl::PointCloud<pcl::PointXYZ>);
	  cleanPointCloud(cloud_to_clean,cloud_cleaned);

	  //Send out filtered cloud to SLAM
	  sensor_msgs::PointCloud2 filtered_ros_cloud;
	  pcl::toROSMsg(*cloud_cleaned,filtered_ros_cloud);
	  kinect_cleaned_publisher.publish(filtered_ros_cloud);

	  //downsample the dataset using a leaf size of 5cm
	  pcl::VoxelGrid<pcl::PointXYZ> vg;
	  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_downsampled (new pcl::PointCloud<pcl::PointXYZ>);
	  vg.setInputCloud (cloud_cleaned);
	  vg.setLeafSize (0.05f, 0.05f, 0.05f);
	  vg.filter (*cloud_downsampled);

	  //std::cout << "PointCloud after filtering has: " << cloud_filtered->points.size ()  << " data points." << std::endl; 
	  //Remove
	  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered (new pcl::PointCloud<pcl::PointXYZ>);
	  removeLowPoints(cloud_downsampled,cloud_filtered);

	  // Creating the KdTree object for the search method of the extraction
	  pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>);
	  tree->setInputCloud (cloud_filtered);

	  std::vector<pcl::PointIndices> cluster_indices;
	  pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
	  ec.setClusterTolerance (0.05); // 5cm
	  ec.setMinClusterSize (100);
	  ec.setMaxClusterSize (25000);
	  ec.setSearchMethod (tree);
	  ec.setInputCloud (cloud_filtered);
	  ec.extract (cluster_indices);
	  Eigen::Vector4f centroid; 
	  Eigen::Vector4f min; 
	  Eigen::Vector4f max; 

	  for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
	  {
		pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_cluster (new pcl::PointCloud<pcl::PointXYZ>);
		for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit)
		  cloud_cluster->points.push_back (cloud_filtered->points[*pit]); //*
		cloud_cluster->width = cloud_cluster->points.size ();
		cloud_cluster->height = 1;
		cloud_cluster->is_dense = true;

		pcl::compute3DCentroid (*cloud_cluster, centroid); 
		pcl::getMinMax3D (*cloud_cluster, min, max);
		
		bool duplicate = false;
	    lock_map();
		for(int i=0;i<slam_map.size();i++){
		  plant p = slam_map->plants[i];
		  dist = sqrt(pow(centroid[0]-p.x),2))+sqrt(pow(centroid[1]-p.y),2))+sqrt(pow(centroid[2]-p.z),2));
		  if(dist<DIST_THRESHOLD){
			duplicate = true;
			break;
		  }
		} 
		if(!duplicate){
		  plant newPlant;
		  newPlant.x = centroid[0];
		  newPlant.y = centroid[1];
          newPlant.z = centroid[2];
          newPlant.width = max[0]-min[0];
          newPlant.length = max[1]-min[1];
          newPlant.height = max[2]-min[2];
          newPlant.id = (int)(plants.size()+1);
          slam_map->plants.push_back(newPlant);
		}
	    unlock_map();
	  }

	}
#else
	void cloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg){
		std::cout << "WARNING! Not compiled with PCL, can't process Kinect pointclouds." << std::endl;
	}
#endif

