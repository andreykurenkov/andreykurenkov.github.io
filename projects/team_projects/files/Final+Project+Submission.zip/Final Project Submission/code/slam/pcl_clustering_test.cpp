#include <stdlib.h> 
#include <iostream>

#ifdef COMPILING_WITH_PCL

#include <boost/thread/thread.hpp>
#include <pcl/common/common_headers.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/console/parse.h>

#include <pcl/PCLPointCloud2.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/conditional_removal.h>
#include <pcl/filters/voxel_grid.h>

#include <pcl/kdtree/kdtree.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/filters/filter.h>
// --------------
// -----Help-----
// --------------
void
printUsage (const char* progName)
{
  std::cout << "\n\nUsage: "<<progName<<" [options]\n\n"
            << "Options: lol no options\n"
            << "\n\n";
}

boost::shared_ptr<pcl::visualization::PCLVisualizer> rgbVis(pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr cloud)
{
  // --------------------------------------------
  // -----Open 3D viewer and add point cloud-----
  // --------------------------------------------
  boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("3D Viewer"));
  viewer->setBackgroundColor (0, 0, 0);
  pcl::visualization::PointCloudColorHandlerRGBField<pcl::PointXYZRGB> rgb(cloud);
  viewer->addPointCloud<pcl::PointXYZRGB> (cloud, rgb, "Test Cloud");
  viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "Test Cloud");
  viewer->addCoordinateSystem (1.0);
  viewer->initCameraParameters ();
  return (viewer);
}

void cleanPointCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud, pcl::PointCloud<pcl::PointXYZRGB>::Ptr out){
	  pcl::StatisticalOutlierRemoval<pcl::PointXYZRGB> sor;
	  sor.setInputCloud (cloud);
	  sor.setMeanK (50);
	  sor.setStddevMulThresh (1.0);
	  sor.filter (*out);
}

void removeLowPoints(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud, pcl::PointCloud<pcl::PointXYZRGB>::Ptr out){
  // build the condition
  pcl::ConditionAnd<pcl::PointXYZRGB>::Ptr range_cond (new
	  pcl::ConditionAnd<pcl::PointXYZRGB> ());
	range_cond->addComparison (pcl::FieldComparison<pcl::PointXYZRGB>::ConstPtr (new
	  pcl::FieldComparison<pcl::PointXYZRGB> ("z", pcl::ComparisonOps::GT, 0.05)));

  // build the filter
  pcl::ConditionalRemoval<pcl::PointXYZRGB> condrem(range_cond);
  condrem.setInputCloud (cloud);
  condrem.setKeepOrganized(true);

  // apply filter
  condrem.filter (*out);
}

void cloudFilter(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud) {
  std::cout << "PointCloud before filtering has: " << cloud->points.size ()  << " data points." << std::endl; 
  cleanPointCloud(cloud,cloud);
  std::cout << "PointCloud after filtering has: " << cloud->points.size ()  << " data points." << std::endl; 
  //downsample the dataset using a leaf size of 5cm
  pcl::VoxelGrid<pcl::PointXYZRGB> vg;
  vg.setInputCloud (cloud);
  vg.setLeafSize (0.05f, 0.05f, 0.05f);
  vg.filter (*cloud);

  std::cout << "PointCloud after downsampling has: " << cloud->points.size ()  << " data points." << std::endl; 
  //Remove
  removeLowPoints(cloud,cloud);
  std::vector<int> indices; 
  pcl::removeNaNFromPointCloud (*cloud,*cloud,indices);

  // Creating the KdTree object for the search method of the extraction
  pcl::search::KdTree<pcl::PointXYZRGB>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZRGB>);
  tree->setInputCloud (cloud);
  std::vector<pcl::PointIndices> cluster_indices;
  pcl::EuclideanClusterExtraction<pcl::PointXYZRGB> ec;
  ec.setClusterTolerance (0.1); // 5cm
  ec.setMinClusterSize (25);
  ec.setMaxClusterSize (500);
  ec.setSearchMethod (tree);
  ec.setInputCloud (cloud);
  ec.extract (cluster_indices);
  int j = 0;
  for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
  {
	uint8_t r(0), g(0), b(0);
  	r = rand()%255;
  	g = rand()%255;
  	b = rand()%255;
	for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit){
	  uint32_t rgb = (static_cast<uint32_t>(r) << 16 |
	          static_cast<uint32_t>(g) << 8 | static_cast<uint32_t>(b));
	  cloud->points[*pit].rgb = *reinterpret_cast<float*>(&rgb);
	}
  }
}

// --------------
// -----Main-----
// --------------
int
main (int argc, char** argv)
{
  // --------------------------------------
  // -----Parse Command Line Arguments-----
  // --------------------------------------
  if (pcl::console::find_argument (argc, argv, "-h") >= 0)
  {
    printUsage (argv[0]);
    return 0;
  }

  // ------------------------------------
  // -----Create example point cloud-----
  // ------------------------------------
  pcl::PointCloud<pcl::PointXYZRGB>::Ptr point_cloud_ptr (new pcl::PointCloud<pcl::PointXYZRGB>);
  std::cout << "Genarating example point clouds.\n\n";

  // We're going to make an ellipse extruded along the z-axis. The colour for
  // the XYZRGB cloud will gradually go from red to green to blue.
  uint8_t r(255), g(15), b(15);
  for (float z(0.0); z <= 0.05; z += 0.01){
    for (int num(0); num <= 1000; num += 1){
      pcl::PointXYZRGB point;
      point.x = ((float)(rand()%100))/20.0;
      point.y = ((float)(rand()%100))/20.0;
      point.z = z;
      uint32_t rgb = (static_cast<uint32_t>(r) << 16 |
              static_cast<uint32_t>(g) << 8 | static_cast<uint32_t>(b));
      point.rgb = *reinterpret_cast<float*>(&rgb);
      point_cloud_ptr->points.push_back (point);
    }
  }

  for (float x(0.0); x <= 5; x += 1){
    for (float y(0.0); y <= 5; y += 1){
      for (float z(0.0); z <= 1; z += 0.05){
        for (int num(0); num <= 10; num += 1){
          pcl::PointXYZRGB point;
          point.x = x+((float)(rand()%100)-50.0)/1000.0+1.0/(z+0.05)*((float)(rand()%100)-50.0)/5000.0;
          point.y = y+((float)(rand()%100)-50.0)/1000.0+1.0/(z+0.05)*((float)(rand()%100)-50.0)/5000.0;
          point.z = z;
          uint32_t rgb = (static_cast<uint32_t>(r) << 16 |
                static_cast<uint32_t>(g) << 8 | static_cast<uint32_t>(b));
          point.rgb = *reinterpret_cast<float*>(&rgb);
          point_cloud_ptr->points.push_back (point);
        }
      }
    }
  }
  point_cloud_ptr->width = (int) point_cloud_ptr->points.size ();
  point_cloud_ptr->height = 1;
  cloudFilter(point_cloud_ptr);
  boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer;
  viewer = rgbVis(point_cloud_ptr);
  
  //--------------------
  // -----Main loop-----
  //--------------------
  while (!viewer->wasStopped ())
  {
    viewer->spinOnce (100);
    boost::this_thread::sleep (boost::posix_time::microseconds (100000));
  }
}

#endif
