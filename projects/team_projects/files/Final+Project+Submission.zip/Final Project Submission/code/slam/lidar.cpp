#include <iostream>
#include <chrono>
#include <thread>
#include "sensor_msgs/LaserScan.h"
#include "ros/ros.h"
#include "util/geom.h"
#include "slam/lidar.h"

#define OBSTACLE_DIST_THRESHOLD 1.0
#define DEBUG_LIDAR 1

void lidarCallback(const sensor_msgs::LaserScan::ConstPtr& msg);
bool obstacleInFront;
ros::NodeHandle* lidarRosHandle;
LidarData latestData;

void init_lidar_obstacle_detection(){
        latestData = new lidar_data();
        lidarRosHandle = new ros::NodeHandle("lidar");
        lidarRosHandle->subscribe("scan", 10, lidarCallback);
}

void lidarCallback(const sensor_msgs::LaserScan::ConstPtr& msg){
    latestData->angle_min = msg->angle_min;
    latestData->angle_max = msg->angle_max;
    latestData->angle_increment = msg->angle_increment;
    latestData->time_increment = msg->time_increment;
    latestData->scan_time = msg->scan_time;
    latestData->range_min = msg->range_min;
    latestData->range_max = msg->range_max;
    latestData->num_values = msg->ranges.size();

    obstacleInFront = false;
    float totalDist = 0;
    int numDists = 0;
    for(int i=0; i < msg->ranges.size();i++){
        float dist = msg->ranges[i];
        if(dist < msg->range_min || dist > msg->range_max)
            continue;
        latestData->ranges[i] = msg->ranges[i];
        float angle = msg->angle_min + i*(msg->angle_increment);
        if(angle>-PI/9 && angle<PI/9){
            totalDist+=dist;
            numDists+=1;
        }
    }
    float average = totalDist/numDists;
    if(DEBUG_LIDAR)
        std::cout << "sum is " << totalDist << " | average is " << average << " with " << numDists << " values." << std::endl;
    obstacleInFront = average<OBSTACLE_DIST_THRESHOLD;
}

bool hasObstacleInFront(){
    return obstacleInFront;
}

LidarData getLatestLidarData(){
    return latestData;
}


