#ifndef LIDAR_H_
#define LIDAR_H_

//Note: must be after ros init
void init_lidar_obstacle_detection();
bool hasObstacleInFront();

typedef struct _lidar_data{
    double angle_min;//      # start angle of the scan [rado
    double angle_max;//      # end angle of the scan [rad]
    double angle_increment;//  # angular distance between measurements [rad]

    double time_increment;//   # time between measurements [seconds] - if your scanner
                          //   # is moving, this will be used in interpolating position
                          //   # of 3d points
    double scan_time;     //    # time between scans [seconds]

    double range_min;     //  # minimum range value [m]
    double range_max;     //  # maximum range value [m]

    double ranges[200];//# range data [m] (Note: values < range_min or > range_max should be discarded)
    int num_values;//number of values

} lidar_data;
typedef lidar_data* LidarData;

LidarData getLatestLidarData();


#endif
