/* 
File purpose: main control loop for frontseat
*/
#include <stdio.h>
#include "navigation/controller.h"
#include "util/timeutil.h"
#include <math.h>
const int CTRL_LOOP_INTERVAL_MS = 100;
const int CTRL_LOOP_MAX_ITER = 3000;
const double ROT_VEL_POINT = 5.0; // in degrees/second
const double POINT_ROT_THETA_TOL = 2; // in degrees
const double POINT_GO_DIST_TOL = 0.08; // in meters
const double MAIN_DRIVE_VEL = 0.15; // in meters/second
const double MM_IN_M = 1000.0;

const double ROBOT_LENGTH_M = 1.0;
const double ROBOT_WIDTH_M = 0.500;
// distance from sprayer to plant
const double SPRAY_CLEARANCE_M = 0.250;
const double SPRAY_DURATION_S = 2.0;

// number of control cycles between sending odometry to gui over tcp
const int CTRL_LOOP_INTERVAL_SEND_ODOM_TCP = 5;

#define VERBOSE 0

double fake_spray_zs[] = {0.0, -10.0, -5.0}; 


// se(3) transformations from robot frame to sprayer frame
se3 se3_robot_to_sprayer, se3_sprayer_to_robot;

void init_controller_constants() {
	se3_robot_to_sprayer.rotation = gen_so3_from_z_rot(0);
	se3_robot_to_sprayer.translation = (vec3){{0.0, ROBOT_WIDTH_M/2.0, 0.0}};
	se3_sprayer_to_robot = se3_inverse(&se3_robot_to_sprayer);
}

typedef struct _rot_dir_analysis {
	bool positive;
	bool willBeFacingAway;
} rot_dir_analysis;

rot_dir_analysis calc_shortest_rot_dir(double curr_th, double point_th) {
	// shortest direction to go either forwards or backwards to the goal
	double th_diff = point_th - curr_th;
	int n_pi = 0;
	while (th_diff < -PI / 2.0) {
		th_diff += PI;
		n_pi ++;
	}
	while (th_diff > PI / 2.0) {
		th_diff -= PI;
		n_pi ++;
	}
	rot_dir_analysis rv;
	rv.positive = th_diff > 0;
	rv.willBeFacingAway = (n_pi % 2) == 1;
	return rv; 
}

int calc_shortest_rot_dir_simple(double curr_th, double des_th) {
	double delta_th_clmp = clamp_0_2pi(des_th - curr_th);
	return delta_th_clmp < PI ? 1 : -1;
}

/*
	row_direction must be unit-length
	returns closest candidate solution to the robot's current location
*/
vec3 calculate_sprayer_location_for_plant(vec3 robot_location, vec3 plant_location, vec3 row_direction) {
	// counter-clockwise solution
	vec3 sol1dir = (vec3){-row_direction.xyz[1], row_direction.xyz[0], 0};
	// clockwise solution
	vec3 sol2dir = (vec3){row_direction.xyz[1], -row_direction.xyz[0], 0};
	vec3 sol1 = vec3_add(plant_location, vec3_scalar_multiply(SPRAY_CLEARANCE_M, sol1dir));
	vec3 sol2 = vec3_add(plant_location, vec3_scalar_multiply(SPRAY_CLEARANCE_M, sol2dir));
	double dist1 = vec3_norm(vec3_subtract(robot_location, sol1));
	double dist2 = vec3_norm(vec3_subtract(robot_location, sol2));
	if (dist1 < dist2) {
		return sol1;
	} else {
		return sol2;
	}
}

se3 calculate_robot_pose_for_spraying_plant(se3 current_robot_pose, vec3 plant_location, so3 row_direction) {
	vec3 sprayer_location = calculate_sprayer_location_for_plant(
		current_robot_pose.translation,
		plant_location,
		so3_get_x_dir(&row_direction)
	);
	// construct an se3 for the sprayer location, x facing down the row
	se3 se3_sprayer;
	se3_sprayer.translation = sprayer_location;
	se3_sprayer.rotation = row_direction;
	
	return se3_multiply(&se3_sprayer, &se3_sprayer_to_robot);

}

void Controller::send_spray_command(vec3 plant_location, double duration) {
	lock_mbed();
    printf("mbed locked.  Sending spray command...\n");

	if (use_mbed_serial) {
		bool succ = serial_send_spray_command(plant_location, duration);
        if (succ) {
		    printf("spray command sent successfully\n");
        } else {
            printf("spray command failed to send\n");
        }
	} else {
		printf("mbed serial disabled, not sending spray command\n");
	}
	unlock_mbed();
}


// update pose estimate from external sources
void Controller::update_pose() {
	// the pose to use depends on whether we are using slam
	// if no slam, then we fall back on odometry
	if (using_slam) {
		// copy pose directly from slam map
		lock_navigation_map();
		pos_analysis.curr_pose = navigation_map -> robot_pose;
		unlock_navigation_map();
	} else {
		// fall back on odometry
		double ex = robot->getX() / MM_IN_M;
		double ey = robot->getY() / MM_IN_M;
		double et = to_radians(robot->getTh());

		pos_analysis. curr_pose. translation = (vec3){ex, ey, 0.0};
		pos_analysis. curr_pose. rotation = gen_so3_from_z_rot(et);
		
	}
}

void Controller::set_rotation_goal(double et, double target_zrot) {
	rot_dir_analysis rot_dir = calc_shortest_rot_dir(et, target_zrot);
	double rot_vel = rot_dir.positive ? ROT_VEL_POINT : -ROT_VEL_POINT;
	// save info about the planned maneuver
	move_state. point_n_go. will_be_facing_away = rot_dir.willBeFacingAway;
	move_state. point_n_go. des_zrot_vel = rot_vel;
	move_state. point_n_go. target_zrot_point = rot_dir.willBeFacingAway ? (target_zrot + PI) : target_zrot;
	printf("Will be facing away? %d\nDesired zrot = %f\n", rot_dir.willBeFacingAway, move_state.point_n_go.target_zrot_point);

}

void Controller::movement_update() {

	char debugbuf[256];


	update_pose();

	se3 curr_pose = pos_analysis. curr_pose;
	double ex, ey, et;
	ex = curr_pose. translation.xyz[0];
	ey = curr_pose. translation.xyz[1];
	et = extract_z_rot(&curr_pose);
	se3 target_pose = move_state. target_pose;

	if (move_state.moving) {
		printf("encoder (x, y, theta) = (%f m, %f m, %f rad)\n", ex, ey, et);
		if (!move_state. point_n_go. active) {
			printf("initializing point-and-go.  target is (%f, %f)\n", 
				target_pose.translation.xyz[0],
				target_pose.translation.xyz[1]);
			move_state. point_n_go. active = 1;
			move_state. point_n_go. stage = POINT;
			// set the angular velocity to aim at the desired translational
			// location
			double ydist = target_pose.translation.xyz[1] - curr_pose.translation.xyz[1];
			double xdist = target_pose.translation.xyz[0] - curr_pose.translation.xyz[0];
			printf("to target: (xdist, ydist) = (%f, %f)\n", xdist, ydist);
			double target_zrot = atan2(ydist, xdist);
			set_rotation_goal(et, target_zrot);
			// begin the robot rotating to align with the direction to the target
			robot->lock();
			robot->enableMotors();
			robot->setRotVel(move_state. point_n_go. des_zrot_vel);
			robot->unlock();
			
		} else {
			// we are currently executing a point-and-go
			if (move_state. point_n_go. stage == POINT ||
				move_state. point_n_go. stage == REPOINT) {
				//monitor status of rotation
				printf("Monitoring rotation status\n");
				// determine if we are within an acceptable approximation of the desired rotation angle
				if (fabs(clamp_0_2pi(et - move_state. point_n_go. target_zrot_point)) < to_radians(POINT_ROT_THETA_TOL)) {
					printf("Within tolerance for pointing\n");
					robot->lock();
					robot->setRotVel(0.0);
					// start moving translationally
					if (move_state. point_n_go. stage == POINT) {
						double ydist = target_pose.translation.xyz[1] - curr_pose.translation.xyz[1];
						double xdist = target_pose.translation.xyz[0] - curr_pose.translation.xyz[0];
						double velToSetMod = move_state.point_n_go.will_be_facing_away ? -1 : 1;
						robot->setVel(velToSetMod * MAIN_DRIVE_VEL*MM_IN_M);
					}
					robot->unlock();
					if (move_state. point_n_go. stage == POINT) {
						move_state. point_n_go. stage = GO;
					} else {
						// reached goal, translationally and rotationally
						move_state. moving = 0;
						move_state. point_n_go. active = 0;
						move_state. flag_goal_reached = 1;
					}
				}
			} else if (move_state. point_n_go. stage == GO) {
				//monitor status of translation

				vec3 curr_tslate = (vec3){{ex,ey,0.0}};
				vec3 des_tslate = target_pose. translation;
				vec3 vecdist = vec3_subtract(des_tslate, curr_tslate);
				double dist = vec3_norm(vecdist);
				printf("Monitoring translation status.  Dist to goal = %f\n", dist);
				vec3_sprint(vecdist, debugbuf); printf("vecdist = %s\n", debugbuf);
				vec3_sprint(des_tslate, debugbuf); printf("dest = %s\n", debugbuf);
				// determine whether we are an acceptable distance from the goal
				if (dist < POINT_GO_DIST_TOL) {
		
					printf("Reached goal translationally\n");
					

					// start repointing rotation
					double target_zrot = extract_z_rot(& move_state. target_pose);
					int rot_dir = calc_shortest_rot_dir_simple(et, target_zrot);
					double rot_vel = rot_dir * ROT_VEL_POINT;
					// save info about the planned maneuver
					move_state. point_n_go. des_zrot_vel = rot_vel;
					move_state. point_n_go. target_zrot_point = target_zrot;
					move_state. point_n_go. stage = REPOINT;


					robot->lock();
					robot->enableMotors();
					robot->setVel(0.0);
					robot->setRotVel(move_state. point_n_go. des_zrot_vel);
					robot->unlock();
					move_state. point_n_go. stage = REPOINT;
				}
				
			}
			
		}
	} else {
		//printf("not moving, nothing todo\n");
	}
	move_state. prev_enc_x = ex;
	move_state. prev_enc_y = ey;
	move_state. prev_enc_th = et;
}

vec3 plant_to_vec3(plant* p) {
	return (vec3){{p->x, p->y, p->z}};
}

se3 Controller::oop_calculate_desired_inposition_pose() {
	se3 rv;

	spray_job* spry_job = spry_job_state. job;
	croparea* crp_area = spry_job->crp_area;

	// we will now travel to the target plant and spray it
	plant target_plant = spry_job_state.target_plant;
	printf("Target plant located at (%f, %f)\n", target_plant.x, target_plant.y);

	// initialize the desired orientation to face along rows
	rv.rotation = crp_area -> orientation;
	printf("Crop area orientation = \n");
	so3_print(&crp_area -> orientation);
	
	// calculate the appropriate pose for positioning for spray
	vec3 row_direction = so3_get_x_dir(& crp_area->orientation);
	printf("Row direction = (%f, %f)\n", row_direction.xyz[0], row_direction.xyz[1]);
	rv = calculate_robot_pose_for_spraying_plant(pos_analysis.curr_pose, plant_to_vec3(&target_plant), crp_area->orientation);
	printf("Sprayer location target = (%f, %f)\n", rv.translation.xyz[0], rv.translation.xyz[1]);
	
	return rv;
}

// navigation_map must be locked first
int Controller::calculate_target_plant_id() {
	int i = 0;
	// target first plant in the map that hasn't been sprayed
	for (i = 0; i < navigation_map -> plants.size(); i ++) {
		plant* p = &navigation_map->plants[i];
		if (spry_job_state.sprayed_plants.count(p -> id) > 0) {
			// we already sprayed this plant, skip
			continue;
		}
		return p -> id;
	}
	return -1;
}

// navigation_map must be locked first
plant get_plant_by_id(int id,LabeledMap map) {
	int i = 0;
	for (i = 0; i < map -> plants.size(); i ++) {
		plant* p = &map->plants[i];
		if (p -> id == id) {
			return *p;
		}
	}
	printf("no plant found with id %d\n");
	exit(1);
}

bool Controller::in_position_to_spray() {
	return true;
}

void Controller::init_controller_tcp_server() {
// initialize the tcp server if applicable

	int server = init_tcp_server(CONFIG_RCV_PORT);
	printf("Server: opened on port %d.  File descriptor = %d\n", CONFIG_RCV_PORT, server);
	
	net_state. server_active = 1;
	net_state. server_file_handle = server;

	// start listening for incoming packets
	start_tcp_listener_thread();

}

void Controller::handle_incoming_json(rapidjson::Document* json) {
	printf("Handling incoming json\n");
	if (json->HasMember("command")) {
		char* cmd = (char*)((*json)["command"].GetString());
		if (strcmp(cmd, "START") == 0) {
			printf("START received\n");
			if (spry_job_state. gui_requested_stop) {
				spry_job_state.gui_requested_stop = false;
			}
		} else if (strcmp(cmd, "STOP") == 0) {
			printf("STOP received.  Stopping spray job.\n");
			spry_job_state. gui_requested_stop = true;
			spry_job_state. started = false;
			move_state. moving = 0;
			move_state.flag_goal_reached = 0;
			spry_job_state.inposition = 0;
			spry_job_state.started_move_into_position = 0;
			move_state.point_n_go.active = 0;
			robot->lock();
			robot->setVel(0.0);
			robot->setRotVel(0.0);
			robot->unlock();
		} else if (strcmp(cmd, "RESETODOM") == 0) {
			printf("Reset odom received, resetting odometry to zero\n");
			robot->lock();
			 ArPose zeroPose(0.0,0.0,0.0);
        		robot->moveTo(zeroPose);
			robot->unlock();

		} 
		else {
			printf("Unknown command: %s\n", cmd);
		}
	}
	
}

// receive packets from GUI (mostly just start, stop commands, and config file)
void tcp_receive_packets(Controller* c, int client, char* databuf) {
    int nread;
    char bbuf[256];
    char* header = "pack";
    int packetOffs = 0;
    char length[4];
    int lengthInt = 0;
    int lengthCount = 0;
    printf("Listening for packets on tcp...\n");



    while ((nread = read(client, bbuf, 255)) > 0) {
        // do stuff with bytes
        for (int i = 0; i < nread; i++) {
            char b = bbuf[i];
            //printf("processing byte: %c\n", b);
            if (packetOffs < 4) {
                //reading in header
                // ensure header matches "pack"
                if (b != header[packetOffs]) {
                    printf("Invalid packet header\n");
		    exit(1);
                }
            } else if (packetOffs >= 4 && packetOffs < 8) {
                //reading the length field
                length[packetOffs - 4] = b;
            } else {
                // reading actual data
                databuf[packetOffs - 8] = b;
                lengthCount++;
                // System.out.println("Length count = "+lengthCount);
                if (lengthCount >= lengthInt) {

                    // call handler
		    databuf[lengthCount] = 0;
                    //System.arraycopy(databuf, 0, databufcmp, 0, lengthCount);
                    //String jsonStr = new String(databufcmp);
                    //System.out.println("Json str from packet: '"+jsonStr+"'");
                    //JSONObject jo = new JSONObject(jsonStr);
                    //processor.process(data, jo);
		    //printf("Received data blob: %s\n", databuf);
		    c -> handle_incoming_json(JSONStringToDocument(databuf));

                    // reset state
                    packetOffs = 0;
                    lengthCount = 0;
                    lengthInt = 0;
                    continue;
                }
            }
            if (packetOffs == 7) {
                //end of length field, need to parse
                lengthInt = length[0] << 24 | length[1] << 16 | length[2] << 8 | length[3];
                // System.out.println("Parsed data length: "+lengthInt);
            }
            packetOffs++;
        }
    }
    printf("Error, tcp connection closed\n");
    
}

void* tcp_listener_thread(void* args) {
	Controller* c = (Controller*) args;
	printf("In tcp_listener thread\n");
	printf("Waiting for a client\n");
	int server = c->net_state.server_file_handle;
	int client = accept_tcp_client(server);
	c->net_state. client_connected = 1;
	c->net_state. client_file_handle = client;
	printf("Server: connected to a client\n");
	printf("Waiting for config file over tcp...\n");

	// fake the config file being received
	// TODO: actually wait for the config
	c->net_state. config_received = 1;

	tcp_receive_packets(c, client, (char*)malloc(4096));
	return NULL;
}

void Controller::start_tcp_listener_thread() {
	printf("Attempting to start tcp_listener_thread\n");
	if(pthread_create(&net_state.listener_thread, NULL, tcp_listener_thread, this)) 	{

		fprintf(stderr, "Error creating tcp listener thread\n");
		exit(1);

	}
}

void Controller::spray_job_update() {
	if (net_state. using_tcp_net) {
		if (!net_state. server_active) {
			init_controller_tcp_server();
			
		}
	}
	if (spry_job_state.started) {
		// if not in position, determine how to get in position
		if (!spry_job_state.inposition) {
			if (!spry_job_state.started_move_into_position) {
				// we're doing a spray job but are out of position.  need to determine
				// the correct position/orientation to goto
				// this will be determined by the plant that we are currently targeting
				int target_plant_id = calculate_target_plant_id();
				printf("Calculated target plant id: %d\n", target_plant_id);
				if (target_plant_id == -1) {
					printf("No plants found.\n");
					// for the demo, we'll reset the plants to spray and start over
					// remove all plant ids in sprayed_plants
					spry_job_state.sprayed_plants.clear();
				} else {
					printf("Target plant id is %d\n", target_plant_id);
					spry_job_state.target_plant = get_plant_by_id(target_plant_id,navigation_map);
					se3 des_pose = oop_calculate_desired_inposition_pose();
					// set the target pose and begin moving
					move_state. target_pose = des_pose;
					move_state. flag_goal_reached = 0;
					move_state. moving = 1;	
					spry_job_state.started_move_into_position = 1;
				}
			} else {
				// wait for goal to be reached
				if (move_state. flag_goal_reached) {
					// goal reached, we're in position
					spry_job_state.inposition = 1;
					spry_job_state.started_move_into_position = 0;
					// we've reached the goal, now to send spray command
					if (in_position_to_spray()) {
						int addl_iterations_to_wait = 2;
						send_spray_command((vec3){0.0, 10.0, fake_spray_zs[spry_job_state.target_plant.id]}, SPRAY_DURATION_S);
						printf("Sent spray command\n");
						spry_state.spraying = 1;
						spry_state.ctl_loop_iteration_timer = ((int)(SPRAY_DURATION_S * 1000.0 / CTRL_LOOP_INTERVAL_MS)) + addl_iterations_to_wait;
						printf("Spraying for %d ctl loop iterations\n", spry_state.ctl_loop_iteration_timer);
					} else {
						printf("Unhandled condition: not in position to spray\n");
					}
				}
			}	
		} //end if not in position
		if (spry_state.spraying) {
			printf("Spraying!\n");
			if (spry_state.ctl_loop_iteration_timer <= 0) {
				printf("Stopping spray.\n");
				spry_state.spraying = 0;
				spry_job_state.sprayed_plants.insert(spry_job_state.target_plant.id);
				// prepare for moving to the next plant
				spry_job_state.inposition = 0;
				spry_job_state.started_move_into_position = 0;
			}
			spry_state.ctl_loop_iteration_timer --;
		}
	} else {
		// spray job not started, need to start if config has been received
		bool ready_to_start = false;		
		if (net_state. using_tcp_net) {
			if (net_state. config_received && !spry_job_state.gui_requested_stop) {
				ready_to_start = true;
			}
		}  else {
			// not using tcp_server
			ready_to_start = true;
		}
		if (ready_to_start) {
			spry_job_state.started = 1;
			spry_job_state.inposition = 0;
			spry_job_state.started_move_into_position = 0;
			printf("Started spray job\n");
		} else {
			//printf("Not starting job until config file received...\n");
		}
	}
}

// returns ptr to next char
char* generate_4x4_json_str(double g[4][4], char* op) {
	int i, j;
	op += sprintf(op, "[");
	for (i = 0; i < 4; i ++) {
		op += sprintf(op, "[");
		for (j = 0; j < 4; j ++) {
			op += sprintf(op, "%f", g[i][j]);
			if (j < 3) {
				op += sprintf(op, ",");
			}
		}
		op += sprintf(op, "]");
		if (i < 3) {
			op += sprintf(op, ",");
		}
	}
	op += sprintf(op, "]");
	return op;
	
}

void Controller::send_odometry_update() {
	if (!net_state. using_tcp_net) {
		return;
	}
	if (!net_state. client_connected) {
		return;
	}
	if (net_state. send_odom_cycle_counter <= 0) {
		printf("Beginning odometry send\n");
		// send odometry
		char buf[1024];
		double gbuf[4][4];
		char* c = buf;
		c += sprintf(c, "{\"odometry\":");
		se3_to_g(&pos_analysis. curr_pose, gbuf);
		c = generate_4x4_json_str(gbuf, c);
		c += sprintf(c, "}");
		*c = 0;
		
		write_rcp_packet(net_state. client_file_handle, buf, strlen(buf));
		//printf("Sent odometry: %s\n", buf);
		net_state.send_odom_cycle_counter = CTRL_LOOP_INTERVAL_SEND_ODOM_TCP;

		// shouldn't be done here, but for the quick demo we are going to read and send back gps data
		// here
		if (use_gps) {
			GPS_data gps_data;
			bool succGPS = getGPSData(&gps_data);
			if (!succGPS) {
				printf("Failed to connect to GPS\n");
			} else {
				printf("Sending GPS data to GUI...\n");
				c = buf;
				c += sprintf(c, "{\"gps\":[%f,%f]}", gps_data.latitude, gps_data.longitude);
				*c = 0;
				write_rcp_packet(net_state. client_file_handle, buf, strlen(buf));
			}
		}

	} else {
		net_state.send_odom_cycle_counter --;
	}
}

void Controller::main_loop_inner() {
    //printf("main loop running\n");    
    lock_navigation_map();
	//printf("spray job update running\n");
    spray_job_update();
    //printf("movement update running\n");
	movement_update();
    //printf("odometry update running\n");
	send_odometry_update();
        unlock_navigation_map();
}

void Controller::main_loop() {
	iter_count = 0;
	last_loop_timestamp = get_time_ms();
	while (1) {
		main_loop_inner();
		iter_count ++;
		if (iter_count >= CTRL_LOOP_MAX_ITER) {
			break;
		}
		last_loop_timestamp = simple_step_timesync(last_loop_timestamp, CTRL_LOOP_INTERVAL_MS);
	}
}

//This was added because we can't do dummy SLAM nicely
//Really should have a Singleton class and pass that in
//(In software dev term)        
void Controller::lock_navigation_map(){
        if(using_slam){
                lock_slam_map();
        }else{
                pthread_mutex_lock(&navigation_map_mutex);
        }
}
        
void Controller::unlock_navigation_map(){
        if(using_slam){
                unlock_slam_map();
        }else{
                pthread_mutex_unlock(&navigation_map_mutex);
        }
}


void Controller::init_net(bool enable_tcp_server) {
	net_state.using_tcp_net = enable_tcp_server;
	net_state.server_active = 0;
	net_state.config_received = 0;
	net_state.send_odom_cycle_counter = 0;
	net_state.client_connected = 0;
}

void Controller::init_common(agribot_config* c, ArRobot* r, bool enable_use_mbed_serial, bool enable_tcp_server, bool using_gps) {
 	//printf("initting controller constants\n");
    init_controller_constants();
    //printf("Controller constants initted\n");
	spry_job_state. started = 0;
	spry_job_state. job = c -> spry_job;
	spry_job_state. gui_requested_stop = 0;
	spry_state. spraying = 0;
	spry_job_state. inposition = 0;
	spry_job_state. started_move_into_position = 0;
	move_state. moving = 0;
	move_state. point_n_go. active = 0;
	move_state. flag_goal_reached = 0;
	robot = r;
	config = c;
	use_mbed_serial = enable_use_mbed_serial;
	use_gps = using_gps;
	//printf("enable_tcp_server = %d\n", enable_tcp_server);
    init_net(enable_tcp_server);
    //printf("init_net finished\n");
	
}

//Uses slam
Controller::Controller(agribot_config* c, ArRobot* r, bool enable_use_mbed_serial, bool enable_tcp_server, bool using_gps) {
	printf("Using real slam, should never be here\n");
    init_common(c, r, enable_use_mbed_serial, enable_tcp_server, using_gps);
        using_slam = true;
        init_slam(robot);
        navigation_map = get_slam_map();

}

//Uses constant map
Controller::Controller(agribot_config* c, ArRobot* r, bool enable_use_mbed_serial, bool enable_tcp_server, LabeledMap map, bool using_gps) {
	//printf("Calling init_common\n");
    init_common(c, r, enable_use_mbed_serial, enable_tcp_server, using_gps);
        using_slam = false;
        navigation_map = map;
	if (pthread_mutex_init(&navigation_map_mutex, NULL) != 0)
	{
		printf("\n slam mutex init failed\n");
		exit(1);
        }

}

