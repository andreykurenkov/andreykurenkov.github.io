#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include "slam/slam.h"
#include "Aria.h"
#include "ArCommands.h"
#include "navigation/config.h"
#include "util/geom.h"
#include "comm/json.h"
#include "comm/net.h"
#include "serial/serial.h"
#include "comm/serialcomm.h"
#include <unordered_set>
#include <thread>

typedef struct _position_analysis {
	se3 curr_pose;
} position_analysis;

enum movement_point_and_go_stage {
	POINT,
	GO,
	REPOINT
};

typedef struct _point_and_go_state {
	bool active;	
	movement_point_and_go_stage stage;
	double target_zrot_point;
	bool will_be_facing_away;
	double des_zrot_vel;
} point_and_go_state;

typedef struct _movement_state {
	bool moving;
	se3 target_pose;
	point_and_go_state point_n_go;
	bool flag_goal_reached;
	double prev_enc_x;
	double prev_enc_y;
	double prev_enc_th;
} movement_state;

typedef struct _spray_job_state {
	bool started;
	bool started_move_into_position;
	bool inposition;
	bool gui_requested_stop;
	spray_job* job;
	plant target_plant;
	unordered_set<int> sprayed_plants;	
} spray_job_state;

typedef struct _spray_state {
	bool spraying;
	// used to wait until the spraying is finished
	int ctl_loop_iteration_timer;
} spray_state;

typedef struct _tcp_net_state {
	bool using_tcp_net;
	bool server_active;
	int server_file_handle;
	int client_file_handle;
	bool client_connected;
	bool config_received;
	pthread_t listener_thread;
	int send_odom_cycle_counter;
} tcp_net_state;

class Controller {
	public:
        //Constructor for navigation based on SLAM
        //Assumed ROS::init has been called
	void init_common(agribot_config* c , ArRobot* r, bool use_real_mbed,bool use_tcp_server, bool using_gps);
	Controller(agribot_config*, ArRobot*, bool use_real_mbed,bool use_tcp_server, bool using_gps);
        //Constructor for navigation based on constant map
	Controller(agribot_config*, ArRobot*, bool use_mbed,bool use_tcp_server, LabeledMap constant_map, bool using_gps);
	ArRobot* robot;
	agribot_config* config;
        LabeledMap navigation_map;
	
	position_analysis pos_analysis;
	spray_state spry_state;
	spray_job_state spry_job_state;
	movement_state move_state;
	tcp_net_state net_state;

	pthread_mutex_t controller_mutex;

        void lock_navigation_map();
        void unlock_navigation_map();
	void main_loop(); 	
	void wait_for_config_file();
	void handle_incoming_json(rapidjson::Document* json);

        private:
	
        int iter_count;
	long long last_loop_timestamp;
	
        bool use_mbed_serial; // true for the real robot, false for testing
	bool using_slam; // true for the real robot, false for testing
	bool use_gps;
        pthread_mutex_t navigation_map_mutex;
	void main_loop_inner();
	se3 oop_calculate_desired_inposition_pose();
	int calculate_target_plant_id();
	bool in_position_to_spray();
	void movement_update();
	void set_rotation_goal(double et, double target_zrot);
	void send_odometry_update();
	void update_pose();
	void spray_job_update();
	void send_spray_command(vec3 plant_location, double duration);
	void init_controller_tcp_server();
	
	void init_net(bool enable_tcp_server);
	void start_tcp_listener_thread() ;

} ;




#endif

