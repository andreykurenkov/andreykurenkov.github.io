%% Forward Kinematics
% Pavel Komarov
% 27/3/2015
% 4/4/2015
function ece4560agrobot
	
	clear; close all;
	
	function rev = Rx(th)
		rev = [1 0 0; 0 cos(th) -sin(th); 0 sin(th) cos(th)];
	end
	
	function rev = Ry(th)
		rev = [cos(th) 0 sin(th); 0 1 0; -sin(th) 0 cos(th)];
	end
	
	function rev = Rz(th)
		rev = [cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1];
	end
	
	%in cm
	a0 = 0;%-20;%tilt of the kinect relative to zero
	l1 = 1.5;%distance from first to second joint
	l2 = 7.5;%distance hose hangs down
	l3 = 11.5;%length of nozzle forward
	
	%27/3/2015
	%The motion of travel of the robot is in +x.
	%The kinect faces +y.
	%Up is +z.
	function ge = forwardagro(a1, a2)
		ge = [Rx(-a0*pi/180) [0; 0; 0]; 0 0 0 1]*...%negative to go backwards (world relative to kinect versus other way)
			[Rx(a1*pi/180) [0; 0; 0]; 0 0 0 1]*...
			[Rz(a2*pi/180) [0; l1; 0]; 0 0 0 1]*...
			[eye(3) [0; l3; l2]; 0 0 0 1];
	end
	
	%take a1 and a2 in degrees
	ge = forwardagro(15, 60)
	
	%4/4/2015
	function a = inverseagro(ge)
		g23 = inv([Rx(-a0*pi/180) [0; 0; 0]; 0 0 0 1])* ...
			ge*inv([eye(3) [0; l3; l2]; 0 0 0 1]);
			
		a = zeros(2,1);
		a(1) = atan2(-g23(2,3), g23(3,3))*180/pi;
		a(2) = atan2(-g23(1,2), g23(1,1))*180/pi;
	end
	
	a = inverseagro(ge)
	
	
	%code to do symbolic math relating 
	sa1 = sym('a1');
	sa2 = sym('a2');
	sa3 = sym('a3');
	sl1 = sym('l1');
	sl2 = sym('l2');
	sl3 = sym('l3');
	deltas = Rx(sa1)*Rz(sa2)*[0; sl3+sa3; sl2] + Rx(sa1)*[0; sl1; 0]
	
	
	%Point the nozzle directly at a particular object in view.
	%x, y, and z are from the camera's perspective
	%
	%Note we have not gotten parts in, so some measurements of length are
	%still provisional.
	%
	function a = finda(x, y, z)
		%x, y, and z are in the camera frame originally. 
		%Get them in the world frame.
		%pw = Rx(a0*pi/180)*[x; y; z];%rotate points down
		
		%We know the world coordinates of the manipulator-base,
		%so subtract to get numerical deltas
		dx = x;%pw(1) - 0;%(-9+4);
		dy = y;%pw(2) - 0;%31;
		dz = z;%pw(3) - 0;%43;
		
		%Use relationships derived on paper to calculate alphas in terms
		%of these deltas and lengths
		a = zeros(3,1);
		a(3) = sqrt(dx^2 + dy^2 + dz^2 - l1^2 - l2^2) - l3;
		a(2) = asin(-dx/(a(3)+l3)) *180/pi;
		
		lx = (a(3)+l3)*cos(a(2)*pi/180)+l1;
		num = -sign(dz)*sqrt( ((dy/dz)^2 + 1) *(lx^2 + l2^2)) + lx*(dy/dz) + l2;%CHANGED
		den = lx - l2*(dy/dz);%CHANGED
		
		a(1) = (-2*atan2(num,den))*180/pi;%CHANGED
	end
	
	a1 = finda(30, 100, 100)
	plotbot(1, 30, 100, 100, a1);
	
	a2 = finda(-25, 50, 20)
	plotbot(2, -25, 50, 20, a2);
	
	a3 = finda(0, 100, -100);
	plotbot(3, 0, 100, -100, a3); 
	
	%a = finda(-10, -10, -10)
	%plotbot(1, -10, -10, -10, a);
	
	
	%display robot arm, point, and spray
	function plotbot(fignum, x, y, z, a)
		figure(fignum);
		hold on;
		axis equal;
		xlabel('x');
		ylabel('y');
		zlabel('z');
	
		pw = Rx(a0*pi/180)*[x; y; z];%rotate points down
		dx = pw(1) - 0;%(-9+4);
		dy = pw(2) - 0;%31;
		dz = pw(3) - 0;%43;
		plot3(dx, dy, dz, 'r*');
	
		g1 = [Rx(a(1)*pi/180) [0; 0; 0]; 0 0 0 1];
		g2 = [Rz(a(2)*pi/180) [0; l1; 0]; 0 0 0 1];
		g3 = [eye(3) [0; 0; l2]; 0 0 0 1];
		g4 = [eye(3) [0; l3; 0]; 0 0 0 1];
		g5 = [eye(3) [0; a(3); 0]; 0 0 0 1];
	
		p0 = g1*g2*[0; 0; 0; 1];
		p1 = g1*g2*g3*[0; 0; 0; 1];
		p2 = g1*g2*g3*g4*[0; 0; 0; 1];
		p3 = g1*g2*g3*g4*g5*[0; 0; 0; 1];
	
		plot3([-4 -4 0 p0(1) p1(1) p2(1)], [-31 0 0 p0(2) p1(2) p2(2)], [0 0 0 p0(3) p1(3) p2(3)]);
		plot3([p2(1) p3(1)], [p2(2) p3(2)], [p2(3) p3(3)], 'g');
	end
		
	
end



