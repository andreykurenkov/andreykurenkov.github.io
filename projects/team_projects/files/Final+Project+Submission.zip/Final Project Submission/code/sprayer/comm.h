#include "DMU.h"
#include "AX12.h"
#include "math.h"
#include  "MODSERIAL.h"

DMU dmu(p5, p6, p7, p13, p14, p15);
MODSERIAL jetson(p28, p27);
AX12 myax121 (p9, p10, 1);
AX12 myax122 (p9, p10, 2);
DigitalOut relay1(p21);
DigitalOut relay2(p22);
DigitalOut relay3(p23);
DigitalOut relay4(p24);
Serial pc(USBTX, USBRX);

#define PI 3.141592654
#define X_OFFSET 0//(-.09+.04)
#define Y_OFFSET 0//.32
#define Z_OFFSET 0//.43
#define L1 0.015
#define L2 0.075
#define L3 0.115


//Data for spray system
struct spray_data {
    float x;
    float y;
    float z;
    float duration;
    int theta_1;
    int phi_2;
};

//Data for IMU sensor
struct sensor_data {
    float x_accel;
    float y_accel;
    float z_accel;
    float roll;
    float pitch;
    float yaw;
};

//Conversions
void float_to_bytes(float coord){
    unsigned char buff[4];
    memcpy(buff, &coord, 4);
    for(int i=0;i<4;i++) jetson.putc(buff[i]);
}

float byte_to_float(){
    unsigned char buff[4];
    float coord;
    //for(int i=0; i<4; i++) {buff[i]=jetson.getc(); pc.putc(buff[i]);}
    buff[0]=jetson.getc();
    buff[1]=jetson.getc();
    buff[2]=jetson.getc();
    buff[3]=jetson.getc();
    memcpy(&coord, buff, 4);
    return coord;
}

//Propagate IMU data
void imu_fill_data(sensor_data *imu){
    imu->x_accel = dmu.acceleration('x');
    imu->y_accel = dmu.acceleration('y');
    imu->z_accel = dmu.acceleration('z');
    imu->pitch = dmu.pitch();
    imu->yaw = dmu.yaw();
    imu->roll = dmu.roll();
}

//Send out IMU data
void send_data(sensor_data imu) {
    //pc.printf("%f %f %f %f %f %f\n", imu.x_accel, imu.y_accel, imu.z_accel, imu.pitch, imu.yaw, imu.roll);
    float_to_bytes(imu.x_accel);
    float_to_bytes(imu.y_accel);
    float_to_bytes(imu.z_accel);
    float_to_bytes(imu.pitch);
    float_to_bytes(imu.yaw);
    float_to_bytes(imu.roll);
}

//Read in spray data from Jetson
void get_data(spray_data *spray){
    spray->x=byte_to_float();
    spray->y=byte_to_float();
    spray->z=byte_to_float();
    spray->duration=byte_to_float();
    jetson.putc(0xAC); //ACK
}

//Convert spray coordinates in to joint angles
void get_coords(spray_data *spray){
    float dist, den, lx, num;
    float angles[] = {0.0,0.0};
    float dx = spray->x - X_OFFSET;
    float dy = spray->y - Y_OFFSET;
    float dz = spray->z - Z_OFFSET;
        
    //Use relationships derived on paper to calculate alphas in terms
    //of these deltas and lengths
    dist = sqrt(dx*dx + dy*dy + dz*dz - L1*L1 - L2*L2) - L3;
    angles[1] = asin(-dx/(dist+L3)) *180/PI;

    lx = (dist+L3)*cos(angles[1]*PI/180)+L1;
    num = (dz>0?-1:1)*sqrt( ((dy/dz)*(dy/dz) + 1) *(lx*lx + L2*L2)) + lx*(dy/dz) + L2;
    den = lx - L2*(dy/dz);
        
    angles[0] = (-2*atan(num/den))*180/PI;
        
    spray->phi_2=150+(int)angles[0];
    spray->theta_1=150+(int)angles[1];
}

//Execute spraying based on coordinates
void spray_action(spray_data spray){
    pc.printf("%f %f %f %f %d %d\n",spray.x,spray.y,spray.z,spray.duration,spray.theta_1,spray.phi_2);
    for(int i=0; i<5; i++) {myax121.SetGoal(spray.phi_2); wait(.01);}
    for(int i=0; i<5; i++) {myax122.SetGoal(spray.theta_1); wait(.01);}
    //pc.printf("hello");
    //send ready
    
    //spray start
    relay1=1;
    relay2=1;
    relay3=1;
    relay4=1;
    wait(spray.duration);
    relay1=0;
    relay2=0;
    relay3=0;
    relay4=0;
    //spray end
}