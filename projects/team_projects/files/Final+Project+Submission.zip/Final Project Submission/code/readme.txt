----SLAM-----

The code for this can be found in the SLAM directory. It compiles as part of a larger package which itself has about 10 dependencies, which is not included (the package.xml and CMakeLists are included at the top level of this folder). The launch files for omnimapper and the kinect transform are in the launch directory.

labeled_map.h defines the map struct that the SLAM is meant to fill. 

slam.h and slam.cpp define the files that include the functionality of sending Odometry data to SLAM and detecting plants. pcl_clustering_test.cpp is a wholly stand-alone piece of code that creates a synthetic point cloud and tests the PCL filtering and clustering steps on it. 

lidar.h and lidar.cpp are the files that subscribe to LIDAR data and implement basic obstacle detection, meant to detect if an obstalce is in front of the robot based on the laser.


----Sprayer----
Contained in the sprayer directory. The Matlab code is hopefully easy to understand. Run with "ik" in a Matlab command window. The code outputs symbolic expressions for the offsets of a point in space from the base of the sprayer in terms of joint angles. This is the system we had to solve to determine manipulator inverse kinematics.

You should notice a sequence of plots also. These simulate the sprayer aiming in space.

In the code at line 70 begins the implementation of the inverse kinematics solutions, the critical bit we implemented also in C (comm.h line 95).



----Navigation

The navigation code, as implemented in the demo, is contained under navigation/controller.cpp.  To compile and link it requires downloading and installing about 10+ huge libraries, so it is not recommended.  Instead a brief overview of the navigation code is given here.

Opening up controller.h, we note the state of the navigation controller.  There is a SE(3) object which contains the robot's estimated pose over time.  It can either be populated by SLAM or directly from the robot odometry.  There are also several state variables (point_and_go_state) which control the robot's movement.  These variables are used to get the robot to simplistically aim at several points and travel forwards or backwards to get there.

Under spray_job_state, and spray_state, we note state variables related to the plant-spraying aspect of the robot.    The robot, at any given time, maintains a "target_plant", which is navigated to and sprayed.  The robot maintains a list of plants that it has already sprayed, in order to not spray the same plant twice.

There are also several other variables and functions meant for communication with other hardware components of the implemented system (e.g, the mbed over RS-232 and the GUI over TCP/IP).

Opening controller.cpp, we see the control logic that acts on these state variables to produce the desired robot behavior.  Near the top of the file is a list of numerical constants that control various aspects of the robot's operation, from its top speed to its pointing and translational tolerances.  There is also a SE(3) object moving from the robot's frame to the sprayer frame.  This transformation is used when sending commands to the sprayer; the sprayer accepts coordinates in the sprayer frame, while SLAM gives plants in the robot frame.

There are various functions throughout controller.cpp that produce desired behaviors, from basic navigation to sending odometry data back over TCP to the GUI running on a client PC.  All functions are run from a periodic main control loop with a time period set by a numeric constant in the top of the file.





